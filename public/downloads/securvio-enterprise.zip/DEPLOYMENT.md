# Securvio Enterprise: Deployment Guide

This document provides instructions for deploying Securvio Enterprise to a production-grade environment.

## 1. Prerequisites
Before deployment, ensure you have:
- A **Google Gemini API Key** (obtained from [Google AI Studio](https://aistudio.google.com/)).
- A hosting provider that supports environment variables (Vercel, Netlify, or Cloudflare Pages are recommended).

## 2. Environment Configuration
Securvio Enterprise relies on a single critical environment variable to communicate with the intelligence engine.

| Variable | Description | Requirement |
| :--- | :--- | :--- |
| `API_KEY` | Your Google Gemini API Key | **Required** |

## 3. Deployment Platforms

### Option A: Vercel (Recommended)
1. **Push your code** to a GitHub, GitLab, or Bitbucket repository.
2. **Import Project** in the Vercel Dashboard.
3. In the **Environment Variables** section, add:
   - Key: `API_KEY`
   - Value: `your_actual_api_key_here`
4. Click **Deploy**. Vercel will automatically detect the static structure and serve the application.

### Option B: Netlify
1. **Connect your repository** to Netlify.
2. Go to **Site Settings > Build & deploy > Environment**.
3. Add a new variable named `API_KEY`.
4. Trigger a new deploy.

### Option C: Manual Static Hosting
If hosting on a standard web server (Nginx/Apache):
- Since this application uses ES6 modules directly in the browser, ensure your server serves `.js` and `.tsx` files with the correct MIME types if you are using a build step.
- **Warning**: Standard static hosting (like GitHub Pages) exposes environment variables in the client-side bundle. For enterprise-grade security, use a provider that supports server-side environment injection or a simple backend proxy.

## 4. Security Best Practices
- **API Key Restrictions**: In the Google Cloud Console, restrict your API key to only allow requests from your production domain (e.g., `https://securvio.yourdomain.com`).
- **CSP Headers**: Implement a Content Security Policy (CSP) that allows connections only to `https://generativelanguage.googleapis.com` and `https://esm.sh`.
- **Compliance**: Ensure that no actual Protected Health Information (PHI) is ever entered into the interface, as this application is currently designed for guidance and regulatory retrieval, not as a primary medical record storage system.

## 5. Maintenance
Securvio Enterprise is built on the `gemini-3-pro-preview` model. Periodically check the `services/geminiService.ts` file to ensure you are using the latest stable model version recommended by Google for your specific enterprise needs.