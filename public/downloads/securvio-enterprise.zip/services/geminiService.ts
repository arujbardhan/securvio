
import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";

export class GeminiService {
  private chat: Chat | null = null;
  private ai: GoogleGenAI | null = null;

  private getAI() {
    if (!this.ai) {
      this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return this.ai;
  }

  async startChat() {
    const ai = this.getAI();
    this.chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.1,
        topP: 0.85,
        topK: 50,
      },
    });
  }

  async generateTitle(firstMessage: string): Promise<string> {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a very short, professional 2-3 word title for a cybersecurity chat based on this first message: "${firstMessage}". Return only the title text.`,
        config: { temperature: 0.3 }
      });
      return response.text?.replace(/["']/g, '').trim() || "Compliance Session";
    } catch (e) {
      return "Strategic Retrieval";
    }
  }

  async sendMessage(message: string): Promise<string> {
    if (!this.chat) {
      await this.startChat();
    }

    try {
      const result = await this.chat!.sendMessage({ message });
      return result.text || "Unauthorized response state. Please re-initiate session.";
    } catch (error: any) {
      console.error("Securvio Engine Error:", error);
      if (error?.message?.includes("429")) {
        return "Critical: Engine over-capacity. Strategic retrieval paused for 30s.";
      }
      return "Critical Error: Intelligence Node offline. Ensure request complies with PHI safety protocols.";
    }
  }

  async *sendMessageStream(message: string) {
    if (!this.chat) {
      await this.startChat();
    }

    try {
      const stream = await this.chat!.sendMessageStream({ message });
      for await (const chunk of stream) {
        const c = chunk as GenerateContentResponse;
        yield c.text || "";
      }
    } catch (error) {
      console.error("Securvio Stream Interrupted:", error);
      yield "Communication line compromised. Syncing backup node...";
    }
  }
}

export const gemini = new GeminiService();
